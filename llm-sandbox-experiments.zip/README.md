# LLM Sandbox Experiments

This repository contains test prompts and jailbreak evaluations for LLMs.